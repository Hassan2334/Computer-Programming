#include <iostream>
using namespace std;

int main() {
    char signal;
    cout << "Enter traffic light color: ";
    cin >> signal;

    switch (signal) {
    case 'R':
    case 'r':
        cout << "STOP";
        break;
    case 'Y':
    case 'y':
        cout << "SLOW DOWN";
        break;
    case 'G':
    case 'g':
        cout << "GO";
        break;
    default:
        cout << "Invalid signal color!";
    }

    return 0;
}