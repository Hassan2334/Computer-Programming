#include <iostream>
using namespace std;

int main() {
    char grade;
    cout << "Enter the grade: ";
    cin >> grade;

    switch (grade) {
    case 'A':
        cout << "Excellent!";
        break;
    case 'B':
        cout << "Good job!";
        break;
    case 'C':
        cout << "You passed.";
        break;
    case 'F':
        cout << "Failed. Try again.";
        break;
    default:
        cout << "Invalid grade!";

    }

    return 0;
}