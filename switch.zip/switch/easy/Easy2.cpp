#include <iostream>
using namespace std;

int main() {
    int choice;
    cout << "Enter the drink number:";
    cin >> choice;

    switch (choice) {
    case 1:
        cout << "Coke";
        break;
    case 2:
        cout << "Sprite";
        break;
    case 3:
        cout << "Fanta";
        break;
    default:
        cout << "Invalid choice! Please pick 1, 2, or 3.";
    }

    return 0;
}