#include <iostream>
using namespace std;

int main() {
    char ch;
    cout << "Enter a lowercase Alphabet:";
    cin >> ch;

    switch (ch) {
    case 'a':
    case 'e':
    case 'i':
    case 'o':
    case 'u':
        cout << "It is a vowel!";
        break;
    default:
        cout << "It is not a vowel!";
    }

    return 0;
}