
#include <iostream>
using namespace std;

int main() {
    char ch;
    cout << "========================================\n";
    cout << "        VOWEL OR CONSONANT DETECTOR     \n";
    cout << "========================================\n";
    cout << "Enter a single alphabet character: ";
    cin >> ch;
    cout << "----------------------------------------\n";

    switch (ch) {
    case 'a': case 'e': case 'i': case 'o': case 'u':
    case 'A': case 'E': case 'I': case 'O': case 'U':
        cout << "Character '" << ch << "' is a VOWEL.\n";
        break;
    case 'b': case 'c': case 'd': case 'f': case 'g':
    case 'h': case 'j': case 'k': case 'l': case 'm':
    case 'n': case 'p': case 'q': case 'r': case 's':
    case 't': case 'v': case 'w': case 'x': case 'y': case 'z':
    case 'B': case 'C': case 'D': case 'F': case 'G':
    case 'H': case 'J': case 'K': case 'L': case 'M':
    case 'N': case 'P': case 'Q': case 'R': case 'S':
    case 'T': case 'V': case 'W': case 'X': case 'Y': case 'Z':
        cout << "Character '" << ch << "' is a CONSONANT.\n";
        break;
    default:
        cout << "Error: Not a valid alphabet letter.\n";
        break;
    }

    cout << "----------------------------------------\n";
    cout << "Analysis complete.\n";
    cout << "========================================\n";

    return 0;
}