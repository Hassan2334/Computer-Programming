#include <iostream>
using namespace std;

int main() {
    char grade;
    cout << "========================================\n";
    cout << "         SIMPLE GRADE EVALUATOR         \n";
    cout << "========================================\n";
    cout << "Enter your letter grade (A, B, C, D, F): ";
    cin >> grade;
    cout << "----------------------------------------\n";

    switch (grade) {
    case 'A':
    case 'a':
        cout << "Grade: A\n";
        cout << "Performance: Excellent! Top honors.\n";
        break;

    case 'B':
    case 'b':
        cout << "Grade: B\n";
        cout << "Performance: Good Job! Above average.\n";
        break;

    case 'C':
    case 'c':
        cout << "Grade: C\n";
        cout << "Performance: Satisfactory. Passed.\n";
        break;

    case 'D':
    case 'd':
        cout << "Grade: D\n";
        cout << "Performance: Needs Improvement.\n";
        break;

    case 'F':
    case 'f':
        cout << "Grade: F\n";
        cout << "Performance: Failed. Try again.\n";
        break;

    default:
        cout << "Error: Invalid grade entered!\n";
        cout << "Please use letters A through F.\n";
        break;
    }

    cout << "----------------------------------------\n";
    cout << "Thank you for using the program!\n";
    cout << "========================================\n";

    return 0;
}