#include <iostream>
using namespace std;

int main() {
    char sizeCode;
    cout << "========================================\n";
    cout << "          COFFEE SIZE CUSTOMIZER        \n";
    cout << "========================================\n";
    cout << "Choose Size (S for Small, M for Medium, L for Large): ";
    cin >> sizeCode;
    cout << "----------------------------------------\n";

    switch (sizeCode) {
    case 'S':
    case 's':
        cout << "Selected: Small Coffee\n";
        cout << "Price: $3.00 | Volume: 8 \n";
        break;
    case 'M':
    case 'm':
        cout << "Selected: Medium Coffee\n";
        cout << "Price: $4.00 | Volume: 12 \n";
        break;
    case 'L':
    case 'l':
        cout << "Selected: Large Coffee\n";
        cout << "Price: $5.00 | Volume: 16 \n";
        break;
    default:
        cout << "Error: Invalid coffee size code.\n";
        break;
    }

    cout << "----------------------------------------\n";
    cout << "Enjoy your fresh brew!\n";
    cout << "========================================\n";

    return 0;
}