#include <iostream>
using namespace std;

int main() {
    int monthNum;
    cout << "========================================\n";
    cout << "           MONTH DAYS COUNTER           \n";
    cout << "========================================\n";
    cout << "Enter month number (1-12): ";
    cin >> monthNum;
    cout << "----------------------------------------\n";

    switch (monthNum) {
    case 1: case 3: case 5: case 7: case 8: case 10: case 12:
        cout << "Month " << monthNum << " has 31 days.\n";
        break;
    case 4: case 6: case 9: case 11:
        cout << "Month " << monthNum << " has 30 days.\n";
        break;
    case 2:
        cout << "Month 2 (February) has 28 or 29 days (leap year).\n";
        break;
    default:
        cout << "Error: Invalid month number! Enter 1 to 12.\n";
        break;
    }

    cout << "----------------------------------------\n";
    cout << "Calendar query completed successfully.\n";
    cout << "========================================\n";

    return 0;
}