#include <iostream>
using namespace std;

int main() {
    int choice;
    double dim1, dim2;
    cout << "========================================\n";
    cout << "         GEOMETRY AREA SELECTOR         \n";
    cout << "========================================\n";
    cout << "1. Square Area\n2. Rectangle Area\n3. Triangle Area\n";
    cout << "Select shape (1-3): ";
    cin >> choice;
    cout << "----------------------------------------\n";

    switch (choice) {
    case 1:
        cout << "Enter side length: ";
        cin >> dim1;
        cout << "Area of Square = " << (dim1 * dim1) << "\n";
        break;
    case 2:
        cout << "Enter length and width: ";
        cin >> dim1 >> dim2;
        cout << "Area of Rectangle = " << (dim1 * dim2) << "\n";
        break;
    case 3:
        cout << "Enter base and height: ";
        cin >> dim1 >> dim2;
        cout << "Area of Triangle = " << (0.5 * dim1 * dim2) << "\n";
        break;
    default:
        cout << "Error: Invalid shape selection.\n";
        break;
    }

    cout << "----------------------------------------\n";
    cout << "Calculation finished.\n";
    cout << "========================================\n";

    return 0;
}