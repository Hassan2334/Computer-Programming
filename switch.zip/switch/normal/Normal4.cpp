#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter a number from 1 to 5: ";
    cin >> num;

    switch (num) {
    case 1:
    case 3:
    case 5:
        cout << num << " is an Odd number." << endl;
        break;
    case 2:
    case 4:
        cout << num << " is an Even number." << endl;
        break;
    default:
        cout << "Number out of range!" << endl;
        break;
    }

    return 0;
}