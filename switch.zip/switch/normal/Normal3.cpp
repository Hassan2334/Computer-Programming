#include <iostream>
using namespace std;

int main() {
    int option;
    double temp;

    cout << "1. Celsius to Fahrenheit\n";
    cout << "2. Fahrenheit to Celsius\n";
    cout << "3. Celsius to Kelvin\n";
    cout << "4. Kelvin to Celsius\n";
    cout << "Choose the conversion type (1-4): ";
    cin >> option;
    cout << "Enter temperature value: ";
    cin >> temp;

    switch (option) {
    case 1:
        cout << temp << " �C = " << (temp * 9 / 5) + 32 << " �F\n";
        break;
    case 2:
        cout << temp << " �F = " << (temp - 32) * 5 / 9 << " �C\n";
        break;
    case 3:
        cout << temp << " �C = " << temp + 273.15 << " K\n";
        break;
    case 4:
        cout << temp << " K = " << temp - 273.15 << " �C\n";
        break;
    default:
        cout << "Invalid selection.";
        break;
    }

    return 0;
}