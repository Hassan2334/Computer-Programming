#include <iostream>
using namespace std;

int main() {
    int age = 20;
    bool hasLicense = true;

    if (age >= 18) {
        if (hasLicense) {
            cout << "You are eligible to drive!" << endl;
        }
        else {
            cout << "You are old enough, but you need a driving license." << endl;
        }
    }
    else {
        cout << "You are too young to drive." << endl;
    }

    return 0;
}