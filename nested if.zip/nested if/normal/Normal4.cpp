#include <iostream>
using namespace std;

int main() {
    int score;
    cout << "Enter the score:";
    cin >> score;

    if (score >= 50) {
        cout << "Status: Passed!" << endl;
        if (score >= 80) {
            cout << "Grade: A" << endl;
        }
        else if (score >= 65) {
            cout << "Grade: B" << endl;
        }
        else {
            cout << "Grade: C" << endl;
        }
    }
    else {
        cout << "Status: Failed" << endl;
    }

    return 0;
}