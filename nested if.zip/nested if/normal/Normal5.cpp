#include <iostream>
using namespace std;

int main() {
    int num1, num2, num3;
    cout << "Enter a num1:";
    cin >> num1;
    cout << "Enter a num2:";
    cin >> num2;
    cout << "Enter a num3:";
    cin >> num3;

    if (num1 >= num2) {
        if (num1 >= num3) {
            cout << "Largest number is: " << num1 << endl;
        }
        else {
            cout << "Largest number is: " << num3 << endl;
        }
    }
    else {
        if (num2 >= num3) {
            cout << "Largest number is: " << num2 << endl;
        }
        else {
            cout << "Largest number is: " << num3 << endl;
        }
    }

    return 0;
}