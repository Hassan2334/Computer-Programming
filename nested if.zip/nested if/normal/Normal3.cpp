#include <iostream>
#include <string>
using namespace std;

int main() {
    string username = "admin";
    int pin = 1234;

    if (username == "admin") {

        if (pin == 1234) {
            cout << "Access granted. Welcome!" << endl;
        }
        else {
            cout << "Incorrect PIN code." << endl;
        }

    }
    else {
        cout << "Username not found." << endl;
    }

    return 0;
}