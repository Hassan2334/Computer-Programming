#include <iostream>
using namespace std;

int main() {
    int num = 14;

    if (num > 0) {
        if (num % 2 == 0) {
            cout << "The number is positive and even.";
        }
    }
    return 0;
}