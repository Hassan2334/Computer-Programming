#include <iostream>
using namespace std;

int main() {
    int score = 95;

    if (score >= 50) {
        cout << "You passed!";
        if (score >= 90) {
            cout << "Excellent! You got a distinction.";
        }
    }
    else {
        cout << "You failed.";
    }
    return 0;
}