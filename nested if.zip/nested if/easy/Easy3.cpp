#include <iostream>
using namespace std;

int main() {
    int age = 20;
    bool hasLicense = true;

    if (age >= 18) {
        cout << "You are an adult." << endl;

        if (hasLicense) {
            cout << "You are allowed to drive!" << endl;
        }
    }

    return 0;
}