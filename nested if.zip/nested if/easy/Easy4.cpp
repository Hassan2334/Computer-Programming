#include <iostream>
#include <string>
using namespace std;

int main() {
    string username, password;

    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    if (username == "admin") {
        if (password == "1234") {
            cout << "Login successful! Welcome admin.";
        }
        else {
            cout << "Wrong password!";
        }
    }
    else {
        cout << "User not found!";
    }

    return 0;
}