#include <iostream>
using namespace std;

int main() {
    cout << "=== Scholarship System ===" << endl;
    double gpa;
    int attendance;
    bool hasProject;
    bool recommendation;

    cout << "Enter GPA: ";
    cin >> gpa;

    if (gpa >= 3.5) {
        cout << "Attendance (%): ";
        cin >> attendance;
        if (attendance >= 85) {
            cout << "Project (1/0): ";
            cin >> hasProject;
            if (hasProject) {
                cout << "Reference (1/0): ";
                cin >> recommendation;
                if (recommendation) {
                    cout << "Approved!" << endl;
                }
                else {
                    cout << "Denied: No ref." << endl;
                }
            }
            else {
                cout << "Denied: No project." << endl;
            }
        }
        else {
            cout << "Denied: Low attendance." << endl;
        }
    }
    else {
        cout << "Denied: Low GPA." << endl;
    }

    return 0;
}