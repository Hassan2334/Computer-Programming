#include <iostream>
using namespace std;

int main() {
    cout << "=== Smart Climate Control System ===" << endl;

    double roomTemperature;
    int humidityLevel;
    bool isPersonHome;
    bool windowOpen;
    cout << "Enter current room temperature (C): ";
    cin >> roomTemperature;

    if (roomTemperature > 22.0) {
        cout << "Is someone currently home? (1 for Yes, 0 for No): ";
        cin >> isPersonHome;

        if (isPersonHome) {
            cout << "Are any windows left open? (1 for Yes, 0 for No): ";
            cin >> windowOpen;

            if (!windowOpen) {
                cout << "Enter current humidity percentage (%): ";
                cin >> humidityLevel;

                if (humidityLevel > 60) {
                    cout << "Action: Turn ON Air Conditioner and Dehumidifier." << endl;
                }
                else {
                    cout << "Action: Turn ON Air Conditioner only." << endl;
                }
            }
            else {
                cout << "Action: Alert - Close windows before activating cooling." << endl;
            }
        }
        else {
            cout << "Action: Economy Mode - Setting temperature to eco-level (26C)." << endl;
        }
    }
    else {
        cout << "Action: Temperature is comfortable. HVAC system is idle." << endl;
    }

    return 0;
}