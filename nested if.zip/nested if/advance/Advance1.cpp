#include <iostream>
using namespace std;

int main() {
    cout << "=== University Admission System ===" << endl;

    int age;
    double percentage;
    bool hasEntranceExam;
    bool hasPassedInterview;
    cout << "Enter your age: ";
    cin >> age;

    if (age >= 17 && age <= 25) {
        cout << "Enter your high school percentage: ";
        cin >> percentage;

        if (percentage >= 60.0) {
            cout << "Did you pass the entrance exam?(1 for Yes, 0 for No): ";
            cin >> hasEntranceExam;

            if (hasEntranceExam) {
                cout << "Did you pass the final interview?(1 for Yes, 0 for No): ";
                cin >> hasPassedInterview;

                if (hasPassedInterview) {
                    cout << "Congratulations! You are fully admitted." << endl;
                }
                else {
                    cout << "Rejected: You failed the final interview stage." << endl;
                }
            }
            else {
                cout << "Rejected: You must pass the entrance exam." << endl;
            }
        }
        else {
            cout << "Rejected: Percentage must be at least 60.0%." << endl;
        }
    }
    else {
        cout << "Rejected: Age must be between 17 and 25 years." << endl;
    }

    return 0;
}