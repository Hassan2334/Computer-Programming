#include <iostream>
using namespace std;

int main() {
    cout << "=== Library Desk ===" << endl;
    int memberId;
    int booksBorrowed;
    bool hasOverdueFines;
    bool isIdValid;
    cout << "Enter Member ID: ";
    cin >> memberId;

    if (memberId > 500) {
        cout << "Is ID card valid? (1/0): ";
        cin >> isIdValid;
        if (isIdValid) {
            cout << "Books currently borrowed: ";
            cin >> booksBorrowed;
            if (booksBorrowed < 3) {
                cout << "Any overdue fines? (1/0): ";
                cin >> hasOverdueFines;
                if (!hasOverdueFines) {
                    cout << "Checkout Approved!" << endl;
                }
                else {
                    cout << "Denied: Pay fines first." << endl;
                }
            }
            else {
                cout << "Denied: Borrow limit reached." << endl;
            }
        }
        else {
            cout << "Denied: Invalid ID card." << endl;
        }
    }
    else {
        cout << "Denied: Member ID too low." << endl;
    }

    return 0;
}