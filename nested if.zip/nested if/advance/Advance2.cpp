#include <iostream>
using namespace std;

int main() {
    cout << "=== Bank Loan Approval System ===" << endl;

    double monthlyIncome;
    int creditScore;
    bool hasExistingDebt;
    int employmentYears;
    cout << "Enter your monthly income ($): ";
    cin >> monthlyIncome;

    if (monthlyIncome >= 3000.0) {
        cout << "Enter your credit score (300-850): ";
        cin >> creditScore;

        if (creditScore >= 680) {
            cout << "Do you have any existing unsecured debt?(1 for Yes, 0 for No): ";
            cin >> hasExistingDebt;

            if (!hasExistingDebt) {
                cout << "Enter your years of continuous employment: ";
                cin >> employmentYears;

                if (employmentYears >= 2) {
                    cout << "Loan Approved! Maximum amount: $50,000." << endl;
                }
                else {
                    cout << "Loan Denied: Employment history is less than 2 years." << endl;
                }
            }
            else {
                cout << "Loan Denied: Existing unsecured debt disqualifies instant approval." << endl;
            }
        }
        else {
            cout << "Loan Denied: Credit score must be 680 or higher." << endl;
        }
    }
    else {
        cout << "Loan Denied: Minimum monthly income requirement is $3,000." << endl;
    }

    return 0;
}